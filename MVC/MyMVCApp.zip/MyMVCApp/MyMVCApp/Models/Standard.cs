﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyMVCApp.Models
{
    public class Standard
    {
        public int StandardId { get; set; }
        public string StandardName { get; set; }
    }
}